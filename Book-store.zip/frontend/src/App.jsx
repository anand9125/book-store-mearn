import { useState } from 'react'
function App() {


  return (
       <div>
       
        <div>Go to routes page</div>

        </div>
      )
    }

export default App

//routes" define the different URLs (or paths) in your application and determine what content or component should be rendered for each UR
//<Route path="/books/:id" element={<Singlebook></Singlebook>}>SingleBook</Route>
//in a route definition in React Router that sets up a dynamic route to render your SingleBook component.
//The path defines the URL pattern for this route.
//:id is a route parameter — it means that any value after /books/ will be captured and stored in a variable called id. 
